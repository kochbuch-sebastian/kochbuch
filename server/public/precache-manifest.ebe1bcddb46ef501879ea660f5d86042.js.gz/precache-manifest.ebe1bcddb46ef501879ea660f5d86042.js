self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8ef6b09997eea6057a9a",
    "url": "/css/app.8c9435b9.css"
  },
  {
    "revision": "6cd59e6f017813280fa81b81fc7f91b9",
    "url": "/img/delete_icon.6cd59e6f.png"
  },
  {
    "revision": "de61f60264d216c85999961d1b1838e4",
    "url": "/img/favorite_icon.de61f602.svg"
  },
  {
    "revision": "8bedd6805be55b3651ddb37ee6a2575a",
    "url": "/img/search_icon.8bedd680.png"
  },
  {
    "revision": "9f0048d79f8f15994afc44d619eba2db",
    "url": "/index.html"
  },
  {
    "revision": "8ef6b09997eea6057a9a",
    "url": "/js/app.9cd5c1f7.js"
  },
  {
    "revision": "9d185e0aa8c78d26c3a1",
    "url": "/js/chunk-vendors.24cf2b01.js"
  },
  {
    "revision": "bdc8609833255674119dea6f6fcdd601",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);